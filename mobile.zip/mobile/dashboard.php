<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('Voting System\php\datevalidation.php');
if (!empty($exp_date)) {
    $newDate = date("m/d/y", strtotime($exp_date));
    $exp = $newDate;
    $today_date = date('m/d/y');
    $td = strtotime($today_date);
    $ed = strtotime($exp);
    if ($td <= $ed) {
        $diff = $td - $ed;
        $days = abs(floor($diff / (60 * 60 * 24)));
        $datemess = "Voting Started! Remaining days:";
        $alert = "alert alert-info";
    } else {
        $datemess = "The schedule for voting is already done!";
        $alert = "alert alert-danger";
    }
} else {
    $datemess = "Schedule to be Announce";
    $alert = "alert alert-primary";
}

if (isset($_SESSION['stno']))
    $sno = $_SESSION['stno'];
include('checkvote.php');

$searchquery = "SELECT * FROM current";
$res = mysqli_query($conn, $searchquery);
if (mysqli_num_rows($res) == 1) {
    $data = mysqli_fetch_array($res);
    $cpres = $data['pres'];
    $cvpresi = $data['vpresi'];
    $cvprese = $data['vprese'];
    $cgensec = $data['gensec'];
    $cdepsec = $data['depsec'];
    $ctrea = $data['trea'];
    $caudi = $data['audi'];
    $cpiom = $data['piom'];
    $cpiof = $data['piof'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="/css/vote.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <title>Dashboard</title>
</head>

<body>
    <header id="navbar">
        <nav class="navbar-container container">
            <div class="home-link">
                <img src="/src/cict.png" class="navbar-logo" />
                Taguig City University<br />
                Computer Science Voting Portal
            </div>
            <button type="button" id="navbar-toggle" aria-controls="navbar-menu" aria-label="Toggle menu" aria-expanded="false">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div id="navbar-menu" aria-labelledby="navbar-toggle">
                <ul class="navbar-links">
                    <?php
                    if (!isset($_SESSION['stno'])) {
                        echo   '<li class="navbar-item"><a class="navbar-link" href="dashboard.php">Home</a></li>
								<li class="navbar-item"><a class="navbar-link" href="login.php">Login</a></li>
								<li class="navbar-item"><a class="navbar-link" href="stats.php">Report</a></li>';
                    } else {
                        echo   '<li class="navbar-item"><a class="navbar-link" href="dashboard.php">Home</a></li>
								<div class="dropdown">
									<button class="navbar-link dropbtn" onclick="myFunction()">Vote </br>
										<i class="fa fa-caret-down mx-2"> </i>
									</button>
									<div class="dropdown-content" id="myDropdown">
										<a class="navbar-link" href="president.php">President</a>
										<a class="navbar-link" href="vpresi.php">VP - Internal</a>
										<a class="navbar-link" href="vprese.php">VP - External</a>
										<a class="navbar-link" href="gensec.php">General Secretary</a>
										<a class="navbar-link" href="depsec.php">Deputy Secretary</a>
										<a class="navbar-link" href="trea.php">Treasurer</a>
										<a class="navbar-link" href="audi.php">Auditor</a>
										<a class="navbar-link" href="piom.php">PIO - Male</a>
										<a class="navbar-link" href="piof.php">PIO - Female</a>
									</div>
								</div>
								<li class="navbar-item"><a class="navbar-link" href="report.php">Voted</a></li>
								<li class="navbar-item"><a class="navbar-link" href="stats.php">Report</a></li>
								<li class="navbar-item"><a class="navbar-link" href="logout.php">Logout</a></li>';
                    }

                    echo '<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>';
                    echo '<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>';
                    ?>
                </ul>
            </div>
        </nav>
    </header>
    <br>
    <div class="<?php echo $alert; ?>" role="alert">
        <h2 class="text-center"><?php echo $datemess; ?></h2>
        <h2 class="text-center"><?php if (!empty($td) && !empty($ed)) if ($td <= $ed) echo $days . " days"; ?></h2>
    </div>
    <div class = "cont">
        </br>
        <h1 class="text-center">Current Partylist</h1>
        <h2 class="text-center">Academic Year 2022</h2>
        <div class="current px-4 py-3">
            <div class="row justify-content-around py-3">
                <div class="col-5 card text-center">
                    <img src="/src/currentpartylist/President.jpg" class="card-img-top py-3 rounded-circle" alt="...">
                    <div class="card-body py-0 px-0">
                        <p class="card-text"><?php echo $cpres; ?></p>
                        <p class="text-secondary"><?php echo "President"; ?></p>
                    </div>
                </div>
            </div>

            <div class="row justify-content-around py-3">
                <div class="col-5 card text-center" style="width: 18rem;">
                    <img src="/src/currentpartylist/Vice President - Internal.jpg" class="card-img-top py-3 rounded-circle" alt="...">
                    <div class="card-body py-0 px-0">
                        <p class="card-text"><?php echo $cvpresi; ?></p>
                        <p class="text-secondary"><?php echo "Vice President - Internal"; ?></p>
                    </div>
                </div>

                <div class="col-5 card text-center" style="width: 18rem;">
                    <img src="/src/currentpartylist/Vice President - External.png" class="card-img-top py-3 rounded-circle" alt="...">
                    <div class="card-body py-0 px-0">
                        <p class="card-text"><?php echo $cvprese; ?></p>
                        <p class="text-secondary"><?php echo "Vice President - External"; ?></p>
                    </div>
                </div>
            </div>

            <div class="row justify-content-around py-3">
                <div class="col-5 card text-center" style="width: 18rem;">
                    <img src="/src/currentpartylist/General Secretary.png" class="card-img-top py-3 rounded-circle" alt="...">
                    <div class="card-body py-0 px-0">
                        <p class="card-text"><?php echo $cgensec; ?></p>
                        <p class="text-secondary"><?php echo "General Secretary"; ?></p>
                    </div>
                </div>

                <div class="col-5 card text-center" style="width: 18rem;">
                    <img src="/src/currentpartylist/Deputy Secretary.jpg" class="card-img-top py-3 rounded-circle" alt="...">
                    <div class="card-body py-0 px-0">
                        <p class="card-text"><?php echo $cdepsec; ?></p>
                        <p class="text-secondary"><?php echo "Deputy Secretary"; ?></p>
                    </div>
                </div>
            </div>

            <div class="row justify-content-around py-3">
                <div class="col-5 card text-center" style="width: 18rem;">
                    <img src="/src/currentpartylist/Treasurer.jpg" class="card-img-top py-3 rounded-circle" alt="...">
                    <div class="card-body py-0 px-0">
                        <p class="card-text"><?php echo $ctrea; ?></p>
                        <p class="text-secondary"><?php echo "Treasurer"; ?></p>
                    </div>
                </div>

                <div class="col-5 card text-center" style="width: 18rem;">
                    <img src="/src/currentpartylist/Auditor.jpeg" class="card-img-top py-3 rounded-circle" alt="...">
                    <div class="card-body py-0 px-0">
                        <p class="card-text"><?php echo $caudi; ?></p>
                        <p class="text-secondary"><?php echo "Auditor"; ?></p>
                    </div>
                </div>
            </div>

            <div class="row justify-content-around py-3">
                <div class="col-5 card text-center" style="width: 18rem;">
                    <img src="/src/currentpartylist/Public Information Officer - Male.JPG" class="card-img-top py-3 rounded-circle" alt="...">
                    <div class="card-body py-0 px-0">
                        <p class="card-text"><?php echo $cpiom; ?></p>
                        <p class="text-secondary"><?php echo "Public Information Officer - Male"; ?></p>
                    </div>
                </div>

                <div class="col-5 card text-center" style="width: 18rem;">
                    <img src="/src/currentpartylist/Public Information Officer - Female.jpg" class="card-img-top py-3 rounded-circle" alt="...">
                    <div class="card-body py-0 px-0">
                        <p class="card-text"><?php echo $cpiof; ?></p>
                        <p class="text-secondary"><?php echo "Public Information Officer - Female"; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <script>
        if (document.getElementById("myDropdown") !== null) {
            function myFunction() {
                document.getElementById("myDropdown").classList.toggle("show");
            }
            window.onclick = function(e) {
                if (!e.target.matches('.dropbtn')) {
                    var myDropdown = document.getElementById("myDropdown");
                    if (myDropdown.classList.contains('show')) {
                        myDropdown.classList.remove('show');
                    }
                }
            }

        }
        const navbarToggle = navbar.querySelector("#navbar-toggle");
        const navbarMenu = document.querySelector("#navbar-menu");
        const navbarLinksContainer = navbarMenu.querySelector(".navbar-links");
        let isNavbarExpanded =
            navbarToggle.getAttribute("aria-expanded") === "true";

        const toggleNavbarVisibility = () => {
            isNavbarExpanded = !isNavbarExpanded;
            navbarToggle.setAttribute("aria-expanded", isNavbarExpanded);
        };

        navbarToggle.addEventListener("click", toggleNavbarVisibility);

        navbarLinksContainer.addEventListener("click", (e) =>
            e.stopPropagation()
        );
        navbarMenu.addEventListener("click", toggleNavbarVisibility);
    </script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>