<?php
require 'vendor/autoload.php';
include('status.php');
include('connection.php');


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('Voting System\php\datevalidation.php');
if (!empty($exp_date)) {
    $newDate = date("m/d/y", strtotime($exp_date));
    $exp = $newDate;
    $today_date = date('m/d/y');
    $td = strtotime($today_date);
    $ed = strtotime($exp);
    if ($td <= $ed) {
        $diff = $td - $ed;
        $days = abs(floor($diff / (60 * 60 * 24)));
        $datemess = "Voting Started! Remaining days:";
        $alert = "alert alert-info";
    } else {
        $datemess = "The schedule for voting is already done!";
        $alert = "alert alert-danger";
    }
} else {
    $datemess = "Schedule to be Announce";
    $alert = "alert alert-primary";
}

?>
<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
<link rel="stylesheet" href="/css/vote.css">
<link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
<title>Report</title>
</head>

<body>
    <header id="navbar">
        <nav class="navbar-container container">
            <div class="home-link">
                <img src="/src/cict.png" class="navbar-logo" />
                Taguig City University<br />
                Computer Science Voting Portal
            </div>
            <button type="button" id="navbar-toggle" aria-controls="navbar-menu" aria-label="Toggle menu" aria-expanded="false">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div id="navbar-menu" aria-labelledby="navbar-toggle">
                <ul class="navbar-links">
                    <?php
                    if (!isset($_SESSION['stno'])) {
                        echo   '<li class="navbar-item"><a class="navbar-link" href="dashboard.php">Home</a></li>
								<li class="navbar-item"><a class="navbar-link" href="login.php">Login</a></li>
								<li class="navbar-item"><a class="navbar-link" href="stats.php">Report</a></li>';
                    } else {
                        echo   '<li class="navbar-item"><a class="navbar-link" href="dashboard.php">Home</a></li>
								<div class="dropdown">
									<button class="navbar-link dropbtn" onclick="myFunction()">Vote </br>
										<i class="fa fa-caret-down mx-2"> </i>
									</button>
									<div class="dropdown-content" id="myDropdown">
										<a class="navbar-link" href="president.php">President</a>
										<a class="navbar-link" href="vpresi.php">VP - Internal</a>
										<a class="navbar-link" href="vprese.php">VP - External</a>
										<a class="navbar-link" href="gensec.php">General Secretary</a>
										<a class="navbar-link" href="depsec.php">Deputy Secretary</a>
										<a class="navbar-link" href="trea.php">Treasurer</a>
										<a class="navbar-link" href="audi.php">Auditor</a>
										<a class="navbar-link" href="piom.php">PIO - Male</a>
										<a class="navbar-link" href="piof.php">PIO - Female</a>
									</div>
								</div>
								<li class="navbar-item"><a class="navbar-link" href="report.php">Voted</a></li>
								<li class="navbar-item"><a class="navbar-link" href="stats.php">Report</a></li>
								<li class="navbar-item"><a class="navbar-link" href="logout.php">Logout</a></li>';
                    }

                    echo '<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>';
                    echo '<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>';
                    ?>
                </ul>
            </div>

        </nav>
    </header><br>
    <div class="<?php echo $alert; ?>" role="alert">
        <h2 class="text-center"><?php echo $datemess; ?></h2>
        <h2 class="text-center"><?php if (!empty($td) && !empty($ed)) if ($td <= $ed) echo $days . " days"; ?></h2>
    </div>
    <div class="cont">
        <br>
        <h1 class="text-center">Statistical Reports</h1>
        <br>
        <div class="pb-3">
            <div class="chart-container">
                <h4 class="text-center">President</h4>
                <canvas id="presidentChart"></canvas>
            </div>
            <div class="chart-container">
                <h4 class="text-center">VP - Internal</h4>
                <canvas id="vpresiChart"></canvas>
            </div>
            <div class="chart-container">
                <h4 class="text-center">VP - External</h4>
                <canvas id="vpreseChart"></canvas>
            </div>
            <div class="chart-container">
                <h4 class="text-center">General Secretary</h4>
                <canvas id="gensecChart"></canvas>
            </div>
            <div class="chart-container">
                <h4 class="text-center">Deputy Secretary</h4>
                <canvas id="depsecChart"></canvas>
            </div>
            <div class="chart-container">
                <h4 class="text-center">Treasurer</h4>
                <canvas id="treaChart"></canvas>
            </div>
            <div class="chart-container">
                <h4 class="text-center">Auditor</h4>
                <canvas id="audiChart"></canvas>
            </div>
            <div class="chart-container">
                <h4 class="text-center">PIO - Male</h4>
                <canvas id="piomChart"></canvas>
            </div>
            <div class="chart-container">
                <h4 class="text-center">PIO - Female</h4>
                <canvas id="piofChart"></canvas>
            </div>
        </div>
    </div>
    <br>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script type="text/javascript">
        if (document.getElementById("myDropdown") !== null) {
            function myFunction() {
                document.getElementById("myDropdown").classList.toggle("show");
            }
            window.onclick = function(e) {
                if (!e.target.matches('.dropbtn')) {
                    var myDropdown = document.getElementById("myDropdown");
                    if (myDropdown.classList.contains('show')) {
                        myDropdown.classList.remove('show');
                    }
                }
            }

        }

        const navbarToggle = navbar.querySelector("#navbar-toggle");
        const navbarMenu = document.querySelector("#navbar-menu");
        const navbarLinksContainer = navbarMenu.querySelector(".navbar-links");
        let isNavbarExpanded =
            navbarToggle.getAttribute("aria-expanded") === "true";

        const toggleNavbarVisibility = () => {
            isNavbarExpanded = !isNavbarExpanded;
            navbarToggle.setAttribute("aria-expanded", isNavbarExpanded);
        };

        navbarToggle.addEventListener("click", toggleNavbarVisibility);

        navbarLinksContainer.addEventListener("click", (e) =>
            e.stopPropagation()
        );
        navbarMenu.addEventListener("click", toggleNavbarVisibility);
        const presidentData = [];
        const vpresiData = [];
        const vpreseData = [];
        const gensecData = [];
        const depsecData = [];
        const treaData = [];
        const audiData = [];
        const piomData = [];
        const piofData = [];

        const socket = new WebSocket('ws://localhost:8080');

        socket.addEventListener('open', (event) => {
            console.log('Connected to WebSocket server');
        });

        socket.addEventListener('message', (event) => {
            const candidatesData = JSON.parse(event.data);
            //console.log('Received data:', candidatesData);

            if (candidatesData.President) {
                presidentData.length = 0;
                for (const obj of candidatesData.President) {
                    presidentData.push({
                        name: obj.pres_name,
                        votes: obj.pres_votes
                    });
                }
                updateChart(presidentChart, presidentData);
            }

            if (candidatesData.Vpresi) {
                vpresiData.length = 0;
                for (const obj of candidatesData.Vpresi) {
                    vpresiData.push({
                        name: obj.vpresi_name,
                        votes: obj.vpresi_votes
                    });
                }
                updateChart(vpresiChart, vpresiData);
            }

            if (candidatesData.Vprese) {
                vpreseData.length = 0;
                for (const obj of candidatesData.Vprese) {
                    vpreseData.push({
                        name: obj.vprese_name,
                        votes: obj.vprese_votes
                    });
                }
                updateChart(vpreseChart, vpreseData);
            }

            if (candidatesData.gensec) {
                gensecData.length = 0;
                for (const obj of candidatesData.gensec) {
                    gensecData.push({
                        name: obj.gensec_name,
                        votes: obj.gensec_votes
                    });
                }
                updateChart(gensecChart, gensecData);
            }

            if (candidatesData.depsec) {
                depsecData.length = 0;
                for (const obj of candidatesData.depsec) {
                    depsecData.push({
                        name: obj.depsec_name,
                        votes: obj.depsec_votes
                    });
                }
                updateChart(depsecChart, depsecData);
            }

            if (candidatesData.trea) {
                treaData.length = 0;
                for (const obj of candidatesData.trea) {
                    treaData.push({
                        name: obj.trea_name,
                        votes: obj.trea_votes
                    });
                }
                updateChart(treaChart, treaData);
            }

            if (candidatesData.audi) {
                audiData.length = 0;
                for (const obj of candidatesData.audi) {
                    audiData.push({
                        name: obj.audi_name,
                        votes: obj.audi_votes
                    });
                }
                updateChart(audiChart, audiData);
            }

            if (candidatesData.piom) {
                piomData.length = 0;
                for (const obj of candidatesData.piom) {
                    piomData.push({
                        name: obj.piom_name,
                        votes: obj.piom_votes
                    });
                }
                updateChart(piomChart, piomData);
            }

            if (candidatesData.piof) {
                piofData.length = 0;
                for (const obj of candidatesData.piof) {
                    piofData.push({
                        name: obj.piof_name,
                        votes: obj.piof_votes
                    });
                }
                updateChart(piofChart, piofData);
            }
        });

        socket.addEventListener('close', (event) => {
            console.log('Disconnected from WebSocket server');
        });

        function updateChart(chart, data) {
            chart.data.labels = data.map(obj => obj.name);
            chart.data.datasets[0].data = data.map(obj => obj.votes);
            chart.update();
        }

        const presidentChart = new Chart(document.getElementById('presidentChart'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'President Votes',
                    data: [],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        const vpresiChart = new Chart(document.getElementById('vpresiChart'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Vice President-Internal Votes',
                    data: [],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        const vpreseChart = new Chart(document.getElementById('vpreseChart'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Vice President-External Votes',
                    data: [],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        const gensecChart = new Chart(document.getElementById('gensecChart'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'General Secretary Votes',
                    data: [],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        const depsecChart = new Chart(document.getElementById('depsecChart'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Deputy Secretary Votes',
                    data: [],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        const treaChart = new Chart(document.getElementById('treaChart'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Treasurer Votes',
                    data: [],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        const audiChart = new Chart(document.getElementById('audiChart'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Auditor Votes',
                    data: [],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        const piofChart = new Chart(document.getElementById('piofChart'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Public Information Officer-Female Votes',
                    data: [],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        const piomChart = new Chart(document.getElementById('piomChart'), {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Public Information Officer-Male Votes',
                    data: [],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

</body>

</html>