<?php
include 'connection.php';
include 'datevalidation.php';
if (!isset($_SESSION['adminname']) || !isset($_SESSION['adminpass'])) {
    header('Location: admin.php');
    exit;
}

if (isset($_POST['start'])) {
    if ($_POST['passconf'] == $_SESSION['adminpass']) {
        include 'wipe.php';
    } else {
        echo '<script language="javascript">';
        echo 'alert("Wrong Credentials")';
        echo '</script>';
    }
}
include('datevalidation.php');
if (!empty($exp_date)) {
    $newDate = date("m/d/y", strtotime($exp_date));
    $exp = $newDate;
    $today_date = date('m/d/y');
    $td = strtotime($today_date);
    $ed = strtotime($exp);
    if ($td <= $ed) {
        $diff = $td - $ed;
        $days = abs(floor($diff / (60 * 60 * 24)));
        $datemess = "Voting Started! Remaining days:";
        $alert = "alert alert-info";
    } else {
        $datemess = "The schedule for voting is already done!";
        $alert = "alert alert-danger";
    }
} else {
    $datemess = "Schedule to be Announce";
    $alert = "alert alert-primary";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/Voting System/stylesheets/sched.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title>Other tools</title>
</head>

<body>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <div class="topnav w-100 py-0 px-0">
        <div class="row pt-2 mt-3 g-0">
            <div class="col-1 d-flex justify-content-end">
                <img src="/src//cict.png" class="img">
            </div>
            <div class="col-9 px-0">
                <h2>Taguig City University</h2>
                <h4>Computer Science Admin Portal</h4>
            </div>
            <div class="col-2 d-flex align-items-center justify-content-center px-0">
                <div class="col-2">
                    <h3><a href="logout.php" style="text-decoration: none; color: black">Logout</a></h3>
                </div>
            </div>
        </div>
        <div class="row flex-row g-0">
            <ul class="d-flex justify-content-around my-0 mx-0">
                <li><a href="dashboard.php" style="text-decoration: none; color: black">Dashboard</a></li>
                <li><a href="voter.php" style="text-decoration: none; color: black">Voter's List</a></li>
                <li><a href="candidate.php" style="text-decoration: none; color: black">Candidates</a></li>
                <li class="act"><a href="schedule.php" style="text-decoration: none; color: black" class = "actbtn">Other</li>
            </ul>
        </div>
    </div>
    <div class="row g-0 justify-content-around my-5">
        <div class="col-3 text-center py-4">
            <div>
                <div class="<?php echo $alert; ?>" role="alert">
                    <h2 class="text-center"><?php echo $datemess; ?></h2>
                    <h2 class="text-center"><?php if (!empty($td) && !empty($ed)) if ($td <= $ed) echo $days . " days"; ?></h2>
                </div>
            </div>
            <div>
                <h2><label for="#schedule">Set schedule:</label></h2>
                <form method="post">
                    <input type="date" name="setdate">
                    <button type="button" id="schedule" name="set" class="btn btn-primary btn-sm mx-2 px-5 " data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                        Set date
                    </button>

                    <!-- Modal -->
                    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-sm">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h2 class="modal-title fs-5" id="staticBackdropLabel">Set schedule</h2>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="" method="post">
                                        <label for=".form-control">Enter password</label>
                                        <input type="password" name="pass" class="form-control">
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <input type="submit" name="submit" value="Submit Date" class="btn btn-primary" data-bs-dismiss="modal"></input></br>
                                    <button data-bs-dismiss="modal" class="btn btn-danger">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="py-5">
                <h2><label for="schedule">Start new Election</label></h2>
                <button type="button" name="set" class="btn btn-danger btn-sm mx-2 px-5 " data-bs-toggle="modal" data-bs-target="#Backdrop">
                    Wipe data
                </button>
                <form method="post">
                    <div class="modal fade" id="Backdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-md">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h2 class="modal-title fs-5" id="staticBackdropLabel">This operation will wipe all data of candidates</h2>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="" method="post">
                                        <label for=".form-control">Enter password</label>
                                        <input type="password" name="passconf" class="form-control">
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <input type="submit" name="start" value="Wipe data" class="btn btn-danger" data-bs-dismiss="modal"></input></br>
                                    <button data-bs-dismiss="modal" class="btn btn-primary">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

</body>

</html>