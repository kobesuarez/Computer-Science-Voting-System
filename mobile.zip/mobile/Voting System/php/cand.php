<?php
session_start();
include 'connection.php';

function insertCandidate($conn, $cname, $cno, $cage, $cgender, $course, $cposition, $cdesc, $cpartylist, $fileurl)
{
    $cname = mysqli_real_escape_string($conn, $cname);
    $cno = mysqli_real_escape_string($conn, $cno);
    $cage = mysqli_real_escape_string($conn, $cage);
    $cgender = mysqli_real_escape_string($conn, $cgender);
    $course = mysqli_real_escape_string($conn, $course);
    $cposition = mysqli_real_escape_string($conn, $cposition);
    $cdesc = mysqli_real_escape_string($conn, $cdesc);
    $cpartylist = mysqli_real_escape_string($conn, $cpartylist);

    try {
        $insertquery = "INSERT INTO candidate (candidatename, candidatestudentnumber, candidateage, candidategender, candidatecourse, candidateposition, candidatedescription, candidatepartylist, candidatepicture) VALUES ('$cname', '$cno', '$cage', '$cgender', '$course', '$cposition', '$cdesc','$cpartylist', '$fileurl')";
        $performquery = mysqli_query($conn, $insertquery);

        if ($performquery) {
            $_SESSION['message'] = '<p class="text-success mb-0"><b>Candidate registered!</b></p>';
        }
    } catch (Exception $e) {
        $_SESSION['message'] = '<p class="text-danger mb-0"><b>Error occurred while registering candidate!</b></p>';
    }
}
if (isset($_POST['submit'])) {
    if($_POST['mname'] == null){
        $_POST['mname'] = "";
    }
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $cname = $fname . ' ' . $mname . ' ' . $lname;
    $cno = $_POST['cno'];
    $cage = $_POST['cage'];
    $cgender = $_POST['cgender'];
    $course = $_POST['course'];
    $cposition = $_POST['cpositions'];
    $cdesc = $_POST['cdesc'];
    $cpartylist = $_POST['cpartylist'];

    // File upload
    $file = $_FILES['my_file']['name'];
    $temp_name = $_FILES['my_file']['tmp_name'];
    $ext = pathinfo($file, PATHINFO_EXTENSION);
    $fileurl = $cno . '.' . $ext;
    $target_dir = "..\\..\\src\\candidate\\$cposition\\";
    $target_file = $target_dir . $fileurl;

    if (move_uploaded_file($temp_name, $target_file)) {
        try {
            $insertpartylist = "INSERT INTO listpartylist (partylist) VALUES ('$cpartylist')";
            $listquery = mysqli_query($conn, $insertpartylist);
            switch ($cposition) {
                case 'President':
                    $insertcandidate = "INSERT INTO president (pres_no, pres_name, pres_votes, pres_desc, partylist) VALUES ('$cno','$cname', '0', '$cdesc','$cpartylist')";
                    break;
                case 'Vice President - Internal':
                    $insertcandidate = "INSERT INTO vpresi (vpresi_no, vpresi_name, vpresi_votes, vpresi_desc, partylist) VALUES ('$cno','$cname', '0', '$cdesc','$cpartylist')";
                    break;
                case 'Vice President - External':
                    $insertcandidate = "INSERT INTO vprese (vprese_no, vprese_name, vprese_votes, vprese_desc, partylist) VALUES ('$cno','$cname', '0', '$cdesc','$cpartylist')";
                    break;
                case 'General Secretary':
                    $insertcandidate = "INSERT INTO gensec (gensec_no, gensec_name, gensec_votes, gensec_desc, partylist) VALUES ('$cno','$cname', '0', '$cdesc','$cpartylist')";
                    break;
                case 'Deputy Secretary':
                    $insertcandidate = "INSERT INTO depsec (depsec_no, depsec_name, depsec_votes, depsec_desc, partylist) VALUES ('$cno','$cname', '0', '$cdesc','$cpartylist')";
                    break;
                case 'Treasurer':
                    $insertcandidate = "INSERT INTO trea (trea_no, trea_name, trea_votes, trea_desc, partylist) VALUES ('$cno','$cname', '0', '$cdesc','$cpartylist')";
                    break;
                case 'Auditor':
                    $insertcandidate = "INSERT INTO audi (audi_no, audi_name, audi_votes, audi_desc, partylist) VALUES ('$cno','$cname', '0', '$cdesc','$cpartylist')";
                    break;
                case 'Public Information Officer - Male':
                    $insertcandidate = "INSERT INTO piom (piom_no, piom_name, piom_votes, piom_desc, partylist) VALUES ('$cno','$cname', '0', '$cdesc','$cpartylist')";
                    break;
                case 'Public Information Officer - Female':
                    $insertcandidate = "INSERT INTO piof (piof_no, piof_name, piof_votes, piof_desc, partylist) VALUES ('$cno','$cname', '0', '$cdesc','$cpartylist')";
                    break;
                default:
                    $_SESSION['message'] = '<p class="text-danger mb-0"><b>Invalid candidate position!</b></p>';
                    exit();
            }

            $inscan = mysqli_query($conn, $insertcandidate);
            insertCandidate($conn, $cname, $cno, $cage, $cgender, $course, $cposition, $cdesc, $cpartylist, $fileurl);
        } catch (Exception $e) {
            $_SESSION['message'] = '<p class="text-danger mb-0"><b>Error occurred while registering candidate!</b></p>';
        }
    } else {
        $_SESSION['message'] = '<p class="text-danger mb-0"><b>File upload failed!</b></p>';
    }
}
header("Location: candidate.php");
exit;
?>