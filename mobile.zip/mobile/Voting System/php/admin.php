<?php

include 'connection.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['adminname']) && isset($_SESSION['adminpass'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if (isset($_POST['login'])) {
    $adminuser = $_POST['username'];
    $adminpass = $_POST['password'];

    if (empty($adminuser) || empty($adminpass)) {
        $error = 'Fields must not be blank!';
    } else {
        $adminuser = mysqli_real_escape_string($conn, $adminuser);
        $adminpass = mysqli_real_escape_string($conn, $adminpass);
        $log = "SELECT * FROM adminacc WHERE adminname = '$adminuser' AND adminpass = '$adminpass'";
        $res = mysqli_query($conn, $log);

        if (mysqli_num_rows($res) == 1) {
            $data = mysqli_fetch_array($res);
            $acc = $data['adminname'];
            $pass = $data['adminpass'];

            $_SESSION['adminname'] = $acc;
            $_SESSION['adminpass'] = $pass;
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Invalid username or password.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="/Voting System/stylesheets/admin.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <title>Administrator Login</title>
</head>

<body>
    <div class="login">
        <div class="loginpanel">
            <h2 class="title">Computer Science Voting Portal</h2>
            <h3 class="collegetitle">Taguig City University</h3>
            <div class="acc d-flex">
                <form method="post" autocomplete="off">
                    <h3 class="adminlog">Admin Log in</h3>
                    <p class="stno">Admin Account</p>
                    <input type="text" name="username" id="logintext">
                    <p class="pword">Password</p>
                    <input type="password" name="password" id="password" class="mr-5">
                    <?php if ($error) : ?>
                        <p class="text-danger mb-0"><b><?php echo $error; ?></b></p>
                    <?php endif; ?>
                    <input type="submit" name='login' id="login" value="Log In" class="my-2">
                </form>
            </div>
        </div>
        <div class="logo">
            <img src="/src/tcu.png" class="imglogo">
        </div>
    </div>
</body>

</html>