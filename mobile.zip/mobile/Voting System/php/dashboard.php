<?php
include 'connection.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['adminname']) || !isset($_SESSION['adminpass'])) {
    header('Location: admin.php');
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/Voting System/stylesheets/dashboard.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title>Administrator</title>
</head>

<body>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <div class="topnav w-100 py-0 px-0">
        <div class="row pt-2 mt-3 g-0">
            <div class="col-1 d-flex justify-content-end">
                <img src="/src//cict.png" class="img">
            </div>
            <div class="col-9 px-0">
                <h2>Taguig City University</h2>
                <h4>Computer Science Admin Portal</h4>
            </div>
            <div class="col-2 d-flex align-items-center justify-content-center px-0">
                <div class="col-2">
                    <h3><a href="logout.php" style="text-decoration: none; color: black">Logout</a></h3>
                </div>
            </div>
        </div>
        <div class="row flex-row g-0">
            <ul class="d-flex justify-content-around my-0 mx-0">
                <li class="act"><a href="dashboard.php" style="text-decoration: none; color: black">Dashboard</li>
                <li><a href="voter.php" style="text-decoration: none; color: black">Voter's List</a></li>
                <li><a href="candidate.php" style="text-decoration: none; color: black">Candidates</a></li>
                <li><a href="schedule.php" style="text-decoration: none; color: black">Other</a></li>
            </ul>
        </div>
    </div>
    <div class="container">
        <div class="row g-0">
            <div class="col-7 mx-3 my-3">
                <h4>Tally</h4>
                <div class="tally h-50 mb-2">
                    <div class="tablelist mx-2 table-responsive">
                        <table class="table table-hover table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Position</th>
                                    <th>Partylist</th>
                                    <th>Votes</th>
                                    <th>Percentage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                include 'connection.php';
                                $filltable = "SELECT `pres_name`, `pres_no`, `partylist`, `pres_votes`, `pres_votes` * 100 / t.s AS `Percentage` FROM president CROSS JOIN( SELECT SUM(`pres_votes`) AS s FROM president ) t";
                                $fill = mysqli_query($conn, $filltable);
                                while ($getrow = mysqli_fetch_array($fill)) {
                                    echo '
                                <tr>
                                    <td>' . $getrow["pres_name"] . '</td>
                                    <td>' . $pos = "President" . '</td>
                                    <td>' . $getrow["partylist"] . '</td>
                                    <td>' . $getrow["pres_votes"] . '</td>
                                    <td>' . $getrow["Percentage"] . '%' . '</td>
                                </tr>
                                ';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <h4>Leading votes per Position</h4>
                <div class="hgraph" height="100vh">
                    <canvas id="partylist" width="700%" height="200%"></canvas>
                </div>
            </div>
            <div class="col-2 mx-3 my-3">
                <h4>Year Level</h4>
                <div class="vgraph" height="100vh">
                    <canvas id="yearlevelchart" width="50%" height="125%"></canvas>
                </div>
            </div>
            <div class="col-2 my-3 mx-3">
                <h4 class="text-center">Top 3 leading</h4>
                <div class="position mb-2">
                    <select class="form-select" name="mySelect" id="position" onchange="showSelectedValue()">
                        <option value="President">President</option>
                        <option value="Vice President - Internal">Vice President - Internal</option>
                        <option value="Vice President - External">Vice President - External</option>
                        <option value="General Secretary">General Secretary</option>
                        <option value="Deputy Secretary">Deputy Secretary</option>
                        <option value="Treasurer">Treasurer</option>
                        <option value="Auditor">Auditor</option>
                        <option value="Public Information Officer - Male">Public Information Officer - Male</option>
                        <option value="Public Information Officer - Female">Public Information Officer - Female</option>
                    </select>
                    <canvas id="pos" width="250%" height="100%"></canvas>
                </div>
                <h4 class="text-center">Voters Status</h4>
                <div class="voters">

                    <canvas id="status"></canvas>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            const leadq = [];
            const statusData = [];
            const yearData = [];
            const leadingData = [];
            var pos = "President";
            if (WebSocket.CLOSED === 3 || WebSocket.CLOSING === 2 || WebSocket.CONNECTING === 0) {
                const socket = new WebSocket('ws://localhost:8080');
                socket.addEventListener('open', (event) => {
                    console.log('Connected to WebSocket server');
                });
                socket.addEventListener('message', (event) => {
                    const candidatesData = JSON.parse(event.data);
                    //console.log(candidatesData);

                    switch (pos) {
                        case "President":
                            leadq.length = 0;
                            for (const obj of candidatesData.President) {
                                leadq.push({
                                    label: obj.pres_name,
                                    data: obj.pres_votes
                                });
                            }
                            updateChart(pospie, leadq);
                            break;
                        case "Vice President - Internal":
                            leadq.length = 0;
                            for (const obj of candidatesData.Vpresi) {
                                leadq.push({
                                    label: obj.vpresi_name,
                                    data: obj.vpresi_votes
                                });
                            }
                            updateChart(pospie, leadq);
                            break;
                        case "Vice President - External":
                            leadq.length = 0;
                            for (const obj of candidatesData.Vprese) {
                                leadq.push({
                                    label: obj.vprese_name,
                                    data: obj.vprese_votes
                                });
                            }
                            updateChart(pospie, leadq);
                            break;
                        case "General Secretary":
                            leadq.length = 0;
                            for (const obj of candidatesData.gensec) {
                                leadq.push({
                                    label: obj.gensec_name,
                                    data: obj.gensec_votes
                                });
                            }
                            updateChart(pospie, leadq);
                            break;
                        case "Deputy Secretary":
                            leadq.length = 0;
                            for (const obj of candidatesData.depsec) {
                                leadq.push({
                                    label: obj.depsec_name,
                                    data: obj.depsec_votes
                                });
                            }
                            updateChart(pospie, leadq);
                            break;
                        case "Treasurer":
                            leadq.length = 0;
                            for (const obj of candidatesData.trea) {
                                leadq.push({
                                    label: obj.trea_name,
                                    data: obj.trea_votes
                                });
                            }
                            updateChart(pospie, leadq);
                            break;
                        case "Auditor":
                            leadq.length = 0;
                            for (const obj of candidatesData.audi) {
                                leadq.push({
                                    label: obj.audi_name,
                                    data: obj.audi_votes
                                });
                            }
                            updateChart(pospie, leadq);
                            break;
                        case "Public Information Officer - Male":
                            leadq.length = 0;
                            for (const obj of candidatesData.piom) {
                                leadq.push({
                                    label: obj.piom_name,
                                    data: obj.piom_votes
                                });
                            }
                            updateChart(pospie, leadq);
                            break;
                        case "Public Information Officer - Female":
                            leadq.length = 0;
                            for (const obj of candidatesData.piof) {
                                leadq.push({
                                    label: obj.piof_name,
                                    data: obj.piof_votes
                                });
                            }
                            updateChart(pospie, leadq);
                            break;
                    }
                    if (candidatesData.lead) {
                        leadingData.length = 0;
                        for (const obj of candidatesData.lead) {
                            leadingData.push({
                                label: obj.pos,
                                data: obj.lVote
                            });
                        }
                        updateChart(partylistbar, leadingData);
                    }
                    if (candidatesData.year) {
                        yearData.length = 0;
                        for (const obj of candidatesData.year) {
                            yearData.push({
                                label: obj.yearLevel,
                                data: obj.total
                            });
                        }
                        updateChart(cookiechart, yearData);
                    }
                    if (candidatesData.vstatus) {
                        statusData.length = 0;
                        for (const obj of candidatesData.vstatus) {
                            statusData.push({
                                label: obj.status,
                                data: obj.total
                            });
                        }
                        updateChart(statuspie, statusData);
                    }
                });
                socket.addEventListener('close', (event) => {
                    console.log('Disconnected from WebSocket server');
                });
            } else {
                console.log('WebSocket is already connected');
            }


            function updateChart(chart, data) {
                chart.data.labels = data.map(obj => obj.label);
                chart.data.datasets[0].data = data.map(obj => obj.data);
                chart.update();
            }


            //yearlevel
            const year = {
                labels: [],
                datasets: [{
                    label: [],
                    data: [],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)'

                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)',
                    ],
                    borderWidth: 1,
                    hoverOffset: 4
                }]
            };
            const dataconfig = {
                type: 'bar',
                data: year
            };
            const cookiechart = new Chart(document.getElementById('yearlevelchart'), dataconfig);

            //first 3 leading per position
            const lead = {
                labels: [],
                datasets: [{
                    label: [],
                    data: [],
                    backgroundColor: [
                        'rgb(255, 99, 132)',
                        'rgb(54, 162, 235)',
                        'rgb(255, 205, 86)'
                    ],
                    hoverOffset: 4
                }]
            };
            const configpos = {
                type: 'doughnut',
                data: lead,
            };
            const pospie = new Chart(document.getElementById('pos'), configpos);

            //status count
            const count = {
                labels: [],
                datasets: [{
                    label: [],
                    data: [],
                    backgroundColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 205, 86)'
                    ],
                    hoverOffset: 4
                }]
            };
            const configstatus = {
                type: 'doughnut',
                data: count,
            };
            const statuspie = new Chart(document.getElementById('status'), configstatus);

            //Leading votes per Position
            const data = {
                labels: [],
                datasets: [{
                    axis: 'x',
                    label: [],
                    data: [],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(93, 155, 155, 0.2)',
                        'rgba(100, 107, 099, 0.2)',
                        'rgba(239, 169, 074, 0.2)',
                        'rgba(037, 041, 074, 0.2)',
                        'rgba(214, 174, 001, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(089, 035, 033)',
                        'rgb(096, 111, 140)',
                        'rgb(193, 135, 107)',
                        'rgb(037, 041, 074)',
                        'rgb(091, 058, 041)'
                    ],
                    borderWidth: 1
                }]
            };
            const config = {
                type: 'bar',
                data: data
            };
            const partylistbar = new Chart(document.getElementById('partylist'), config);

            function showSelectedValue() {
                var selectElement = document.getElementById("position");
                var selectedValue = selectElement.value;
                var selectedText = selectElement.options[selectElement.selectedIndex].text;
                pos = selectedValue;
            }
        </script>
</body>

</html>