<?php 
include 'connection.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

    if(isset($_POST['start'])){
        if($_POST['passconf'] == $_SESSION['adminpass']){
            $del = "TRUNCATE TABLE setsched";
            $d = mysqli_query($conn, $del);
            $del = "TRUNCATE TABLE audi";
            $d = mysqli_query($conn, $del);
            $del = "TRUNCATE TABLE candidate";
            $d = mysqli_query($conn, $del);
            $del = "TRUNCATE TABLE depsec";
            $d = mysqli_query($conn, $del);
            $del = "TRUNCATE TABLE gensec";
            $d = mysqli_query($conn, $del);
            $del = "TRUNCATE TABLE listpartylist";
            $d = mysqli_query($conn, $del);
            $del = "TRUNCATE TABLE piof";
            $d = mysqli_query($conn, $del);
            $del = "TRUNCATE TABLE piom";
            $d = mysqli_query($conn, $del);
            $del = "TRUNCATE TABLE president";
            $d = mysqli_query($conn, $del);
            $del = "TRUNCATE TABLE totalvotestracker";
            $d = mysqli_query($conn, $del);
            $del = "TRUNCATE TABLE trea";
            $d = mysqli_query($conn, $del);
            $del = "TRUNCATE TABLE vpresi";
            $d = mysqli_query($conn, $del);
            $del = "TRUNCATE TABLE vprese";
            $d = mysqli_query($conn, $del);

            $updatestud = "UPDATE studentvote set votedpres = '0', votedvpresi = '0', votedvprese = '0', votedgs = '0', votedds = '0', votedtrea = '0', votedaudi = '0', votedpiom = '0', votedpiof = '0', vstatus = 'Not Voted' WHERE 1";
            $up = mysqli_query($conn, $updatestud);
        }else{
            echo '<script language="javascript">';
            echo 'alert("Wrong Credentials")';
            echo '</script>';
        }
    }



?>