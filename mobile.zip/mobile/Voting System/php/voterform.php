<?php
include 'connection.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';


$length = 10;
$keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

$str = '';
$max = mb_strlen($keyspace, '8bit') - 1;
for ($i = 0; $i < $length; ++$i) {
    $str .= $keyspace[random_int(0, $max)];
}
if (isset($_POST['signup'])) {
    // Check if all fields are filled
    if (
        empty($_POST['fname']) || empty($_POST['sno']) || empty($_POST['smail']) ||
        empty($_POST['syear']) || empty($_POST['scon']) || empty($_POST['section'])
    ) {
        $_SESSION['message'] = '<p class="text-danger mb-0"><b>All fields are required!</b></p>';
    } else {
        $sname = $_POST['fname'];
        $sno = $_POST['sno'];
        $smail = $_POST['smail'];
        $syear = $_POST['syear'];
        $section = $_POST['section'];
        $scno = $_POST['scon'];
        $votingstatus = 0;
        $sname = mysqli_real_escape_string($conn, $sname);
        $sno = mysqli_real_escape_string($conn, $sno);
        $smail = mysqli_real_escape_string($conn, $smail);
        $syear = mysqli_real_escape_string($conn, $syear);
        $section = mysqli_real_escape_string($conn, $section);
        $scno = mysqli_real_escape_string($conn, $scno);

        // Check if email already exists in the database
        $emailCheckQuery = "SELECT * FROM studentlist WHERE studentemail = '$smail'";
        $emailCheckResult = mysqli_query($conn, $emailCheckQuery);
        if (mysqli_num_rows($emailCheckResult) > 0) {
            $_SESSION['message'] = '<p class="text-danger mb-0"><b>Email already exists. Please choose a different email.</b></p>';
        } else {
            // Check if student number already exists in the database
            $snoCheckQuery = "SELECT * FROM studentlist WHERE studentnumber = '$sno'";
            $snoCheckResult = mysqli_query($conn, $snoCheckQuery);
            if (mysqli_num_rows($snoCheckResult) > 0) {
                $_SESSION['message'] = '<p class="text-danger mb-0"><b>Student number already exists. Please choose a different student number.</b></p>';
            } else {
                try {
                    $insertquery = "INSERT INTO studentlist(studentname, studentnumber, studentemail, studentcourse, studentyear, studentsection, studentcontactnumber, studentpassword) VALUES ('$sname', '$sno', '$smail', '$scourse','$syear', '$section', '$scno', '$str')";
                    $performquery = mysqli_query($conn, $insertquery);

                    if ($performquery) {
                        $vinsertquery = "INSERT INTO studentvote(sno, votedpres, votedvpresi, votedvprese, votedgs, votedds, votedtrea, votedaudi, votedpiom, votedpiof, vstatus) VALUES ('$sno', 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Not Voted')";
                        $vperformquery = mysqli_query($conn, $vinsertquery);

                        if ($vperformquery) {
                            $mail = new PHPMailer(true);

                            try {
                                $mail->isSMTP();
                                $mail->Host = 'smtp.gmail.com';
                                $mail->SMTPAuth = true;
                                $mail->Username = 'kobe.suarez18@gmail.com';
                                $mail->Password = 'ookrlbxnpfpbfwza';
                                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                                $mail->Port = 465;

                                //Recipients
                                $mail->setFrom('kobe.suarez18@gmail.com');
                                $mail->addAddress($_POST['smail']);

                                //Content
                                $mail->isHTML(true);
                                $mail->Subject = 'Account for CICT Voting Website';
                                $mail->Body = 'Your username will be: <b>' . $sno . '</b></=> And your Password is: <b>' . $str . '</b>. </br><a href="http://localhost:3000/login.php/">Click here</a> to Login your account';

                                $mail->send();
                                $_SESSION['message'] = '<p class="text-success mb-0"><b>Student registered!</b></p>';
                            } catch (Exception $e) {
                                $_SESSION['message'] = "<p class='text-danger mb-0'><b>Message could not be sent. Mailer Error: {$mail->ErrorInfo}</b></p>";
                            }
                        } else {
                            $_SESSION['message'] = '<p class="text-danger mb-0"><b>Error occurred while performing the student vote query.</b></p>';
                        }
                    } else {
                        $_SESSION['message'] = '<p class="text-danger mb-0"><b>Error occurred while performing the student query.</b></p>';
                    }
                } catch (Exception $e) {
                    $_SESSION['message'] = '<p class="text-danger mb-0"><b>Student already exists!</b></p>';
                }
            }
        }
    }
}
header("Location: voter.php");
exit;
?>