<?php
if (session_status() === PHP_SESSION_NONE) {
	session_start();
}
$_SESSION['stno'] = "asdas";
if (isset($_SESSION['stno']))
	$sno = $_SESSION['stno'];
?>

<!DOCTYPE html>
<html>

<head>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
	<link rel="stylesheet" href="/css/vote.css">
</head>

<body>
	<header id="navbar">
		<nav class="navbar-container container">
			<div class="home-link">
				<img src="/src/cict.png" class="navbar-logo" />
				Taguig City University<br />
				Computer Science Voting Portal
			</div>
			<button type="button" id="navbar-toggle" aria-controls="navbar-menu" aria-label="Toggle menu" aria-expanded="false">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<div id="navbar-menu" aria-labelledby="navbar-toggle">
				<ul class="navbar-links">
					<?php
					if (!isset($_SESSION['stno'])) {
						echo   '<li class="navbar-item"><a class="navbar-link" href="dashboard.php">Home</a></li>
								<li class="navbar-item"><a class="navbar-link" href="login.php">Login</a></li>
								<li class="navbar-item"><a class="navbar-link" href="stats.php">Report</a></li>';
					} else {
						echo   '<li class="navbar-item"><a class="navbar-link" href="dashboard.php">Home</a></li>
								<div class="dropdown">
									<button class="navbar-link dropbtn" onclick="myFunction()">Vote </br>
										<i class="fa fa-caret-down"> </i>
									</button>
									<div class="dropdown-content" id="myDropdown">
										<a class="navbar-link" href="president.php">President</a>
										<a class="navbar-link" href="vpresi.php">VP - Internal</a>
										<a class="navbar-link" href="vprese.php">VP - External</a>
										<a class="navbar-link" href="gensec.php">General Secretary</a>
										<a class="navbar-link" href="depsec.php">Deputy Secretary</a>
										<a class="navbar-link" href="trea.php">Treasurer</a>
										<a class="navbar-link" href="audi.php">Auditor</a>
										<a class="navbar-link" href="piom.php">PIO - Male</a>
										<a class="navbar-link" href="piof.php">PIO - Female</a>
									</div>
								</div>
								<li class="navbar-item"><a class="navbar-link" href="report.php">Voted</a></li>
								<li class="navbar-item"><a class="navbar-link" href="stats.php">Report</a></li>
								<li class="navbar-item"><a class="navbar-link" href="logout.php">Logout</a></li>';
					}

					echo '<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>';
					echo '<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>';
					?>
				</ul>
			</div>

		</nav>
	</header>


	<script>
		function myFunction() {
			document.getElementById("myDropdown").classList.toggle("show");
		}

		window.onclick = function(e) {
			if (!e.target.matches('.dropbtn')) {
				var myDropdown = document.getElementById("myDropdown");
				if (myDropdown.classList.contains('show')) {
					myDropdown.classList.remove('show');
				}
			}
		}
		const navbarToggle = navbar.querySelector("#navbar-toggle");
		const navbarMenu = document.querySelector("#navbar-menu");
		const navbarLinksContainer = navbarMenu.querySelector(".navbar-links");
		let isNavbarExpanded =
			navbarToggle.getAttribute("aria-expanded") === "true";

		const toggleNavbarVisibility = () => {
			isNavbarExpanded = !isNavbarExpanded;
			navbarToggle.setAttribute("aria-expanded", isNavbarExpanded);
		};

		navbarToggle.addEventListener("click", toggleNavbarVisibility);

		navbarLinksContainer.addEventListener("click", (e) =>
			e.stopPropagation()
		);
		navbarMenu.addEventListener("click", toggleNavbarVisibility);
	</script>
</body>

</html>