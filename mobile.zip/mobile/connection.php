<?php
$host = "localhost"; // Your database host
$user = "root"; // Your database username
$password = ""; // Your database password
$database = "votingsystem"; // Your database name

// Create a connection
$conn = mysqli_connect($host, $user, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>