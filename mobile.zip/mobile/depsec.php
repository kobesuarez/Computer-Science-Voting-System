<?php
include('checkvote.php');

include('Voting System\php\datevalidation.php');
if (!empty($exp_date)) {
    $newDate = date("m/d/y", strtotime($exp_date));
    $exp = $newDate;
    $today_date = date('m/d/y');
    $td = strtotime($today_date);
    $ed = strtotime($exp);
    if ($td <= $ed) {
        $diff = $td - $ed;
        $days = abs(floor($diff / (60 * 60 * 24)));
        $datemess = "Voting Started! Remaining days:";
        $alert = "alert alert-info";
    } else {
        $datemess = "The schedule for voting is already done!";
        $alert = "alert alert-danger";
        header("Location: stats.php");
    }
} else {
    $datemess = "Schedule to be Announce";
    $alert = "alert alert-primary";
    header("Location: Dashboard.php");
}
if (isset($_SESSION['stno'])) {
    $sno = $_SESSION['stno'];
    if ($depsec == 0) {
            if (isset($_POST['votedepsec'])) {
                $id = $_POST['votedepsec'];
                $votequery = "SELECT depsec_votes FROM depsec WHERE depsec_no = '$id'";
                $vote = mysqli_query($conn, $votequery);
                $data = mysqli_fetch_array($vote);
                $getvote = $data['depsec_votes'];
                $getvote = $getvote + 1;
                $updatevote = "UPDATE depsec SET depsec_votes = '$getvote' WHERE depsec_no = '$id'";
                mysqli_query($conn, $updatevote);
                $updatestudent = "UPDATE studentvote SET votedds = '$id' WHERE sno = '$sno'";
                mysqli_query($conn, $updatestudent);
                $getstatus = "SELECT * from studentvote WHERE sno = '$sno'";
                $res = mysqli_query($conn, $getstatus);
                while ($getrow = mysqli_fetch_array($res)) {
                    $pres = $getrow["votedpres"];
                    $vpresi = $getrow["votedvpresi"];
                    $vprese = $getrow["votedvprese"];
                    $gensec = $getrow["votedgs"];
                    $depsec = $getrow["votedds"];
                    $trea = $getrow["votedtrea"];
                    $audi = $getrow["votedaudi"];
                    $piom = $getrow["votedpiom"];
                    $piof = $getrow["votedpiof"];
                    if ((($pres != "0") && ($vpresi != "0") && ($vprese != "0") && ($gensec != "0") && ($depsec != "0") && ($trea != "0") && ($audi != "0") && ($piom != "0") && ($piof != "0"))) {
                        $updatequery = "UPDATE studentvote set vstatus = 'Voted' WHERE sno = '$sno'";
                        $up = mysqli_query($conn, $updatequery);
                    }
                }
                header('Location: trea.php');
                exit;
            }
        } else {
            header('Location: trea.php');
            exit;
        }
    } else {
        header('Location: dashboard.php');
        exit;
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="/css/vote.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <title>Vote Deputy Secretary</title>
</head>

<body>
    <header id="navbar">
        <nav class="navbar-container container">
            <div class="home-link">
                <img src="/src/cict.png" class="navbar-logo" />
                Taguig City University<br />
                Computer Science Voting Portal
            </div>
            <button type="button" id="navbar-toggle" aria-controls="navbar-menu" aria-label="Toggle menu" aria-expanded="false">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div id="navbar-menu" aria-labelledby="navbar-toggle">
                <ul class="navbar-links">
                    <?php
                    if (!isset($_SESSION['stno'])) {
                        echo   '<li class="navbar-item"><a class="navbar-link" href="dashboard.php">Home</a></li>
								<li class="navbar-item"><a class="navbar-link" href="login.php">Login</a></li>
								<li class="navbar-item"><a class="navbar-link" href="stats.php">Report</a></li>';
                    } else {
                        echo   '<li class="navbar-item"><a class="navbar-link" href="dashboard.php">Home</a></li>
								<div class="dropdown">
									<button class="navbar-link dropbtn" onclick="myFunction()">Vote
										<i class="fa fa-caret-down mx-2"> </i>
									</button>
									<div class="dropdown-content" id="myDropdown">
										<a class="navbar-link" href="president.php">President</a>
										<a class="navbar-link" href="vpresi.php">VP - Internal</a>
										<a class="navbar-link" href="vprese.php">VP - External</a>
										<a class="navbar-link" href="gensec.php">General Secretary</a>
										<a class="navbar-link" href="depsec.php">Deputy Secretary</a>
										<a class="navbar-link" href="trea.php">Treasurer</a>
										<a class="navbar-link" href="audi.php">Auditor</a>
										<a class="navbar-link" href="piom.php">PIO - Male</a>
										<a class="navbar-link" href="piof.php">PIO - Female</a>
									</div>
								</div>
								<li class="navbar-item"><a class="navbar-link" href="report.php">Voted</a></li>
								<li class="navbar-item"><a class="navbar-link" href="stats.php">Report</a></li>
								<li class="navbar-item"><a class="navbar-link" href="logout.php">Logout</a></li>';
                    }

                    echo '<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>';
                    echo '<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>';
                    ?>
                </ul>
            </div>

        </nav>
    </header><br>
    <div class="cont">
        <br>
        <h2 class="text-center">Deputy Secretary</h2>
        <div class="pb-3">
            <?php
            include('connection.php');
            $countquery = "SELECT * FROM candidate WHERE candidateposition = 'Deputy Secretary'";
            $countres = mysqli_query($conn, $countquery);
            while ($getrow = mysqli_fetch_array($countres)) {
                $cname = $getrow["candidatename"];
                $cstno = $getrow["candidatestudentnumber"];
                $cpos = $getrow["candidateposition"];
                $cdesc = $getrow["candidatedescription"];
                $cpartylist = $getrow["candidatepartylist"];
                $imageurl = $getrow["candidatepicture"];
                echo '<div>
        <form method="post">
            <div class="col-12 card text-center" style="width: 18rem;">
                <img src="src/candidate/Deputy Secretary/' . $imageurl . '" class="card-img-top py-3 rounded-circle" alt="...">
                <div class="card-body py-0 px-0">
                    <p class="card-text mb-1">' . $cname . '</p>
                    <p class="text-secondary mb-0">' . $cpos . '</p>
                    <p class="text-secondary">' . $cpartylist . '</p>
                    <button type="button" class="btndesc btn btn-sm mx-2 px-5 mb-2" data-bs-toggle="modal" data-bs-target="#desc' . $cstno . '">Description</button>
                    <button type="button" class="btnvote btn btn-sm mx-2 px-5 mb-2" data-bs-toggle="modal" data-bs-target="#conf' . $cstno . '">Vote ' . $cname . '</button>
                </div>
            </div>

            <div class="modal fade" id="desc' . $cstno . '" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title fs-5" id="staticBackdropLabel">' . $cname . '\'s description</h2>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p style="white-space: pre-line">' . $cdesc . '</p>
                        </div>
                    </div>
                </div>
            </div>';

    echo '<div class="modal fade" id="conf' . $cstno . '" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog modal-md">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title fs-5" id="staticBackdropLabel">Vote ' . $cname . '</h2>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p style="white-space: pre-line">Are you to vote ' . $cname . '?</p>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-primary mb-2" type="submit" name="votedepsec" value="' . $cstno . '">Vote ' . $cname . '</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>';
            }
            ?>
        </div>
    </div>
    <br>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    
    <script>
        if (document.getElementById("myDropdown") !== null) {
            function myFunction() {
                document.getElementById("myDropdown").classList.toggle("show");
            }
            window.onclick = function(e) {
                if (!e.target.matches('.dropbtn')) {
                    var myDropdown = document.getElementById("myDropdown");
                    if (myDropdown.classList.contains('show')) {
                        myDropdown.classList.remove('show');
                    }
                }
            }

        }
        const navbarToggle = navbar.querySelector("#navbar-toggle");
        const navbarMenu = document.querySelector("#navbar-menu");
        const navbarLinksContainer = navbarMenu.querySelector(".navbar-links");
        let isNavbarExpanded =
            navbarToggle.getAttribute("aria-expanded") === "true";

        const toggleNavbarVisibility = () => {
            isNavbarExpanded = !isNavbarExpanded;
            navbarToggle.setAttribute("aria-expanded", isNavbarExpanded);
        };

        navbarToggle.addEventListener("click", toggleNavbarVisibility);

        navbarLinksContainer.addEventListener("click", (e) =>
            e.stopPropagation()
        );
        navbarMenu.addEventListener("click", toggleNavbarVisibility);
    </script>
</body>

</html>