<?php 
include('status.php');
include('connection.php');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if(isset($_SESSION['stno']))
    $sno = $_SESSION['stno'];

if(isset($sno)){
    $getstatus = "SELECT * from studentvote WHERE sno = '$sno'";
    $res = mysqli_query($conn, $getstatus);
    while ($getrow = mysqli_fetch_array($res)) {
        $pres = $getrow["votedpres"];
        $vpresi = $getrow["votedvpresi"];
        $vprese = $getrow["votedvprese"];
        $gensec = $getrow["votedgs"];
        $depsec = $getrow["votedds"];
        $trea = $getrow["votedtrea"];
        $audi = $getrow["votedaudi"];
        $piom = $getrow["votedpiom"];
        $piof = $getrow["votedpiof"];
        $_SESSION['pres'] = $pres;
        $_SESSION['vpresi'] = $vpresi;
        $_SESSION['vprese'] = $vprese;
        $_SESSION['dgs'] = $depsec;
        $_SESSION['dds'] = $gensec;
        $_SESSION['trea'] = $trea;
        $_SESSION['audi'] = $audi;
        $_SESSION['piom'] = $piom;
        $_SESSION['piof'] = $piof;
        $bpres = $_SESSION['pres'];
$bvpresi = $_SESSION['vpresi'];
$bvprese = $_SESSION['vprese'];
$bdgs = $_SESSION['dgs'];
$bdds = $_SESSION['dds'];
$btrea = $_SESSION['trea'];
$baudi = $_SESSION['audi'];
$bpiom = $_SESSION['piom'];
$bpiof = $_SESSION['piof'];
    }
}

?>